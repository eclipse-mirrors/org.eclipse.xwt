package demo;

import java.net.URL;

import org.eclipse.e4.xwt.IConstants;
import org.eclipse.e4.xwt.XWT;

import org.eclipse.swt.widgets.Composite;

public class Hello extends Composite{

	public Hello(Composite parent, int style) {
		super(parent, style);
		// TODO Auto-generated constructor stub
	}

}


