package demo;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import org.eclipse.e4.xwt.IConstants;
import org.eclipse.e4.xwt.XWT;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;

public class Application {

	public static void main(String[] argus) throws Exception {

		URL file = Hello.class.getResource("Hello.xwt");

		Shell shell = XWT.load(file).getShell();
		shell.pack();
		shell.open();
		while(!shell.isDisposed()){
			if(!shell.getDisplay().readAndDispatch()){
				shell.getDisplay().sleep();
			}
		}
	}

}
